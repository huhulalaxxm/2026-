#include "system.h"
#include "SysTick.h"
#include "usart.h"
#include "led.h"
#include "tftlcd.h"

#define VIDEO_UART_BAUD       921600
#define VIDEO_MAGIC0          0xA5
#define VIDEO_MAGIC1          0x5A
#define VIDEO_MAGIC2          0x10
#define VIDEO_MAGIC3          0x30
#define VIDEO_HEADER_TIMEOUT  3000
#define VIDEO_BYTE_TIMEOUT    1000
#define VIDEO_MAX_WIDTH       160
#define VIDEO_MAX_HEIGHT      120
#define VIDEO_ACK             0x06

static u16 video_frame[VIDEO_MAX_WIDTH*VIDEO_MAX_HEIGHT];

static u8 UART_ReadByte(u8 *data,u32 timeout_ms)
{
    u32 start=HAL_GetTick();
    while((USART1->SR&USART_SR_RXNE)==0)
    {
        if((HAL_GetTick()-start)>=timeout_ms)return 0;
    }
    *data=(u8)(USART1->DR&0xff);
    return 1;
}

static void UART_DiscardBytes(u32 len)
{
    u8 temp;
    while(len--)
    {
        if(UART_ReadByte(&temp,VIDEO_BYTE_TIMEOUT)==0)break;
    }
}

static void UART_WriteByte(u8 data)
{
    while((USART1->SR&USART_SR_TXE)==0);
    USART1->DR=data;
}

static u8 Video_WaitHeader(u16 *width,u16 *height)
{
    u8 data;
    u8 state=0;
    u8 wh[4];

    while(1)
    {
        if(UART_ReadByte(&data,VIDEO_HEADER_TIMEOUT)==0)return 0;

        if((state==0&&data==VIDEO_MAGIC0)||
           (state==1&&data==VIDEO_MAGIC1)||
           (state==2&&data==VIDEO_MAGIC2)||
           (state==3&&data==VIDEO_MAGIC3))
        {
            state++;
            if(state==4)break;
        }
        else
        {
            state=(data==VIDEO_MAGIC0)?1:0;
        }
    }

    if(UART_ReadByte(&wh[0],VIDEO_BYTE_TIMEOUT)==0)return 0;
    if(UART_ReadByte(&wh[1],VIDEO_BYTE_TIMEOUT)==0)return 0;
    if(UART_ReadByte(&wh[2],VIDEO_BYTE_TIMEOUT)==0)return 0;
    if(UART_ReadByte(&wh[3],VIDEO_BYTE_TIMEOUT)==0)return 0;

    *width=(u16)wh[0]|((u16)wh[1]<<8);
    *height=(u16)wh[2]|((u16)wh[3]<<8);
    return 1;
}

static u8 Video_ReadFrame(u16 width,u16 height)
{
	u16 x;
	u16 y;
	u8 lo;
	u8 hi;

	if(width==0||height==0)return 0;
	if(width>VIDEO_MAX_WIDTH||height>VIDEO_MAX_HEIGHT||
	   width>tftlcd_data.width||height>tftlcd_data.height)
	{
		UART_DiscardBytes((u32)width*height*2);
		return 0;
	}

	for(y=0;y<height;y++)
	{
		for(x=0;x<width;x++)
		{
			if(UART_ReadByte(&lo,VIDEO_BYTE_TIMEOUT)==0)return 0;
			if(UART_ReadByte(&hi,VIDEO_BYTE_TIMEOUT)==0)return 0;
			video_frame[(u32)y*width+x]=((u16)hi<<8)|lo;
		}
	}
	return 1;
}

static void Video_DrawFrame(u16 width,u16 height)
{
	u16 x;
	u16 y;
	u16 dx;
	u16 dy;
	u16 sx;
	u16 sy;
	u16 scale;
	u16 color;

	scale=tftlcd_data.width/width;
	if((tftlcd_data.height/height)<scale)scale=tftlcd_data.height/height;
	if(scale==0)scale=1;

	sx=(tftlcd_data.width-width*scale)/2;
	sy=(tftlcd_data.height-height*scale)/2;

	for(y=0;y<height;y++)
	{
		for(dy=0;dy<scale;dy++)
		{
			LCD_Set_Window(sx,sy+y*scale+dy,sx+width*scale-1,sy+y*scale+dy);
			for(x=0;x<width;x++)
			{
				color=video_frame[(u32)y*width+x];
				for(dx=0;dx<scale;dx++)
				{
					LCD_WriteData_Color(color);
				}
			}
		}
	}
}

int main()
{
    u8 i=0;
    u16 width=0;
    u16 height=0;

    HAL_Init();
    SystemClock_Init(RCC_PLL_MUL9);
    SysTick_Init(72);
    USART1_Init(VIDEO_UART_BAUD);
    __HAL_UART_DISABLE_IT(&UART1_Handler,UART_IT_RXNE);
    LED_Init();
    TFTLCD_Init();

    FRONT_COLOR=BLACK;
    BACK_COLOR=WHITE;
    LCD_Clear(WHITE);
    LCD_ShowString(10,10,tftlcd_data.width,tftlcd_data.height,16,"Waiting camera stream...");
    LCD_ShowString(10,35,tftlcd_data.width,tftlcd_data.height,16,"UART: 921600  RGB565");
    printf("PZ103 video receiver ready\r\n");

    while(1)
    {
        if(Video_WaitHeader(&width,&height))
        {
            if(Video_ReadFrame(width,height))
            {
                Video_DrawFrame(width,height);
                UART_WriteByte(VIDEO_ACK);
                LED1=!LED1;
            }
        }
        else
        {
            i++;
            if(i%2==0)LED2=!LED2;
        }
    }
}
